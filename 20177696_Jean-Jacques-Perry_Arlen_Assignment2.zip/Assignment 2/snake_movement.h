#ifndef SNAKEMOVEMENT_H
#define SNAKEMOVEMENT_H
#include "linkedlist.h"

void movement(LinkedListNode* currentNode);

#endif