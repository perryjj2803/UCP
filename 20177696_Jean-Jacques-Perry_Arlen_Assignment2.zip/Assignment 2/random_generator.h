#ifndef RANDOMGENERATOR_H
#define RANDOMGENERATOR_H

void initRandom();
int Random(int low, int high);

#endif