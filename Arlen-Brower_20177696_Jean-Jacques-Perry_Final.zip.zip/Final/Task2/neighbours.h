#ifndef NEIGHBOURS_H
#define NEIGHBOURS_H

int neighbours(int** playArea, int xValue, int yValue);

#endif