#!/bin/bash

grep [^aeiou]$ name.txt