#!/bin/bash

grep "am" name.txt | sort
